// ============================================================
//  POKER BOX TRACKER — Google Apps Script (Multi-Box)
//  One sheet holds all boxes. Each row has a Box ID + Name.
//  Paste this into your Google Sheet's Apps Script editor,
//  then Deploy → New deployment → Web App.
// ============================================================

var SHEET_NAME = "Entries";

// ── Ensure the sheet exists with headers ───────────────────
function getOrCreateSheet() {
  var ss    = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    var headers = [
      "Box ID", "Box Name", "ID", "Date",
      "IN Last", "IN This", "OUT Last", "OUT This",
      "Money In", "Money Out", "Profit", "Multiplier", "Saved At"
    ];
    sheet.appendRow(headers);
    var header = sheet.getRange(1, 1, 1, headers.length);
    header.setBackground("#0f2416");
    header.setFontColor("#c8a84b");
    header.setFontWeight("bold");
    sheet.setFrozenRows(1);
    sheet.setColumnWidth(1, 140);
    sheet.setColumnWidth(2, 120);
    sheet.setColumnWidth(4, 120);
  }
  return sheet;
}

// ── GET — return all entries, optionally filtered by boxId ──
function doGet(e) {
  try {
    var sheet  = getOrCreateSheet();
    var data   = sheet.getDataRange().getValues();
    var boxId  = e && e.parameter && e.parameter.boxId ? e.parameter.boxId : null;

    if (data.length <= 1) {
      return jsonResponse({ success: true, entries: [] });
    }

    var entries = [];
    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      if (!row[2]) continue; // skip blank / summary rows
      if (row[0] === "TOTAL") continue;
      if (boxId && row[0] !== boxId) continue; // filter by box
      entries.push({
        boxId:      row[0],
        boxName:    row[1],
        id:         row[2],
        date:       row[3],
        inLast:     row[4],
        inThis:     row[5],
        outLast:    row[6],
        outThis:    row[7],
        moneyIn:    row[8],
        moneyOut:   row[9],
        profit:     row[10],
        multiplier: row[11],
        savedAt:    row[12]
      });
    }
    return jsonResponse({ success: true, entries: entries });
  } catch(err) {
    return jsonResponse({ success: false, error: err.toString() });
  }
}

// ── POST — handle actions ───────────────────────────────────
function doPost(e) {
  try {
    var payload = JSON.parse(e.postData.contents);
    var action  = payload.action;

    if (action === "syncBox") {
      // Replace all rows for a specific box, keep others intact
      return syncBox(payload.boxId, payload.boxName, payload.entries);
    }
    if (action === "syncAll") {
      // Full replace of all data from all boxes
      return syncAll(payload.boxes);
    }
    if (action === "add") {
      return addEntry(payload.entry);
    }
    return jsonResponse({ success: false, error: "Unknown action: " + action });
  } catch(err) {
    return jsonResponse({ success: false, error: err.toString() });
  }
}

// ── Sync a single box (replace its rows, keep others) ──────
function syncBox(boxId, boxName, entries) {
  var sheet   = getOrCreateSheet();
  var lastRow = sheet.getLastRow();

  // Delete rows belonging to this box (scan from bottom to top)
  if (lastRow > 1) {
    var data = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    for (var r = data.length - 1; r >= 0; r--) {
      if (data[r][0] === boxId || data[r][0] === "TOTAL") {
        sheet.deleteRow(r + 2);
      }
    }
  }

  // Append this box's entries
  if (entries && entries.length > 0) {
    var rows = entries.map(function(entry) {
      return [
        boxId, boxName, entry.id, entry.date,
        entry.inLast, entry.inThis, entry.outLast, entry.outThis,
        entry.moneyIn, entry.moneyOut, entry.profit,
        entry.multiplier, new Date().toISOString()
      ];
    });
    sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, 13).setValues(rows);
  }

  formatSheet(sheet);
  refreshTotals(sheet);
  return jsonResponse({ success: true, message: "Box synced: " + boxName });
}

// ── Full sync all boxes at once ─────────────────────────────
function syncAll(boxes) {
  var sheet   = getOrCreateSheet();
  var lastRow = sheet.getLastRow();
  if (lastRow > 1) sheet.deleteRows(2, lastRow - 1);

  var allRows = [];
  (boxes || []).forEach(function(box) {
    (box.entries || []).forEach(function(entry) {
      allRows.push([
        box.id, box.name, entry.id, entry.date,
        entry.inLast, entry.inThis, entry.outLast, entry.outThis,
        entry.moneyIn, entry.moneyOut, entry.profit,
        entry.multiplier, new Date().toISOString()
      ]);
    });
  });

  if (allRows.length > 0) {
    sheet.getRange(2, 1, allRows.length, 13).setValues(allRows);
  }

  formatSheet(sheet);
  refreshTotals(sheet);
  return jsonResponse({ success: true, message: "Full sync: " + allRows.length + " rows" });
}

// ── Add a single entry row ──────────────────────────────────
function addEntry(entry) {
  var sheet = getOrCreateSheet();
  // Remove old TOTAL rows before appending
  var lastRow = sheet.getLastRow();
  if (lastRow > 1) {
    var lastVal = sheet.getRange(lastRow, 1).getValue();
    if (lastVal === "TOTAL") sheet.deleteRow(lastRow);
  }

  sheet.appendRow([
    entry.boxId, entry.boxName, entry.id, entry.date,
    entry.inLast, entry.inThis, entry.outLast, entry.outThis,
    entry.moneyIn, entry.moneyOut, entry.profit,
    entry.multiplier, new Date().toISOString()
  ]);

  formatSheet(sheet);
  refreshTotals(sheet);
  return jsonResponse({ success: true, message: "Entry added" });
}

// ── Format data rows ────────────────────────────────────────
function formatSheet(sheet) {
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  // Group rows by box for alternating colors per box
  var data     = sheet.getRange(2, 1, lastRow - 1, 13).getValues();
  var boxTrack = {};
  var colorA   = "#0a1a0f";
  var colorB   = "#0f2416";
  var toggle   = false;
  var lastBox  = null;

  for (var r = 0; r < data.length; r++) {
    var row   = data[r];
    var boxId = row[0];
    if (boxId === "TOTAL") continue;
    if (boxId !== lastBox) { toggle = !toggle; lastBox = boxId; }
    var bg = toggle ? colorA : colorB;
    sheet.getRange(r + 2, 1, 1, 13).setBackground(bg).setFontColor("#f0ece0");
  }

  // Format money columns (9, 10, 11 = Money In, Out, Profit)
  if (lastRow >= 2) {
    sheet.getRange(2, 9, lastRow - 1, 3).setNumberFormat("$#,##0");
    // Color profit column
    for (var row2 = 2; row2 <= lastRow; row2++) {
      var cell = sheet.getRange(row2, 11);
      var val  = cell.getValue();
      if (val > 0)      cell.setFontColor("#00ff88");
      else if (val < 0) cell.setFontColor("#d63031");
      else              cell.setFontColor("#8a9e8f");
    }
  }
}

// ── Per-box totals rows at the bottom ──────────────────────
function refreshTotals(sheet) {
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  // Remove any existing TOTAL rows
  for (var r = lastRow; r >= 2; r--) {
    if (sheet.getRange(r, 1).getValue() === "TOTAL") sheet.deleteRow(r);
  }

  // Recalculate from data
  var data    = sheet.getRange(2, 1, sheet.getLastRow() - 1, 13).getValues();
  var totals  = {}; // boxId -> {name, in, out, profit}

  data.forEach(function(row) {
    var bid = row[0];
    if (!bid || bid === "TOTAL") return;
    if (!totals[bid]) totals[bid] = { name: row[1], moneyIn: 0, moneyOut: 0, profit: 0 };
    totals[bid].moneyIn  += Number(row[8])  || 0;
    totals[bid].moneyOut += Number(row[9])  || 0;
    totals[bid].profit   += Number(row[10]) || 0;
  });

  // Append one TOTAL row per box
  Object.keys(totals).forEach(function(bid) {
    var t = totals[bid];
    sheet.appendRow(["TOTAL", t.name, "", "", "", "", "", "", t.moneyIn, t.moneyOut, t.profit, "", ""]);
    var tr  = sheet.getLastRow();
    var rng = sheet.getRange(tr, 1, 1, 13);
    rng.setBackground("#c8a84b").setFontColor("#0a1a0f").setFontWeight("bold");
    sheet.getRange(tr, 9, 1, 3).setNumberFormat("$#,##0");
  });
}

// ── JSON helper ─────────────────────────────────────────────
function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
